﻿public class DefinePerson
{
    public static void Main()
    {
    }
}

